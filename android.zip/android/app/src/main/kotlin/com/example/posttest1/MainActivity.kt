package com.example.posttest1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
