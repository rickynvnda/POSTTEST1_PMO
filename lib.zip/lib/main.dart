import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: MainPage(),
    );
  }
}

class MainPage extends StatelessWidget {
  const MainPage({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    var lebar = MediaQuery.of(context).size.width;
    var tinggi = MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
        title: const Text("POSTTEST 1 - RICKY 073"),
      ),
      body: Container(
        padding: const EdgeInsets.all(1),
        width: lebar,
        height: tinggi,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Color.fromARGB(255, 11, 135, 207),
                Color.fromARGB(255, 225, 240, 112),
                Color.fromARGB(255, 239, 69, 143),
              ]),
        ),
        child: Container(
          width: lebar / 1.5,
          height: tinggi / 4,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: Color.fromARGB(255, 243, 217, 72),
            border: Border.all(
              color: Color.fromARGB(255, 211, 211, 211),
              width: 3,
            ),
            borderRadius: BorderRadius.circular(25),
          ),
          child: const Text(
            "Hii, Saya\nRICKY NOVENDA PUTRA\n2009106073\nINFORMATIKA B20",
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 20,
              color: Color.fromARGB(255, 159, 96, 40),
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }
}
